package com.odenktools.daogenerator;

import de.greenrobot.daogenerator.DaoGenerator;
import de.greenrobot.daogenerator.Entity;
import de.greenrobot.daogenerator.Schema;


/**
 * Generates entities and DAOs for the example project DaoExample.
 * <p/>
 * Run it as a Java application (not Android).
 */
public class AppDaoGenerator {


    public static void main(String[] args) throws Exception {

        Schema schema = new Schema(21, "com.odenktools.android.dao");

        addTag(schema);
        addChannel(schema);
        addFeatureProgram(schema);
        addFilm(schema);
        addAcaraSekarang(schema);
        addBerita(schema);
        addSelebrity(schema);
        addAccount(schema);
        addDetailAcara(schema);
        addAktifitas(schema);
        addNotification(schema);
        addRecommendedShow(schema);
        addUlasan(schema);
        addWatchList(schema);
        addFoto(schema);
        addCategory(schema);
        addItemNews(schema);
        addNewsGroup(schema);
        addJadwalBola(schema);
        addTerkait(schema);
        addVideo(schema);
        addZodiak(schema);
        addProfesi(schema);
        addComment(schema);

        new DaoGenerator().generateAll(schema, "../android/src/main/java");
    }

    private static void addComment(Schema schema) {
        Entity challenge = schema.addEntity("Comment");
        challenge.setHasKeepSections(true);
        challenge.setTableName("Comment");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("parentId");
        challenge.addStringProperty("objectType");
        challenge.addStringProperty("objectId");
        challenge.addStringProperty("memberId");
        challenge.addStringProperty("content");
        challenge.addStringProperty("date");
        challenge.addStringProperty("memberName");
        challenge.addStringProperty("memberImage");
    }

    private static void addProfesi(Schema schema) {
        Entity challenge = schema.addEntity("Profesi");
        challenge.setHasKeepSections(true);
        challenge.setTableName("Profesi");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("profesi");
    }

    private static void addZodiak(Schema schema) {
        Entity challenge = schema.addEntity("Zodiak");
        challenge.setHasKeepSections(true);
        challenge.setTableName("Zodiak");

        challenge.addStringProperty("zodiak").primaryKey();
    }

    private static void addVideo(Schema schema) {

        Entity challenge = schema.addEntity("Video");
        challenge.setHasKeepSections(true);
        challenge.setTableName("Video");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("title");
        challenge.addStringProperty("description");
        challenge.addStringProperty("image");
        challenge.addStringProperty("video");
    }

    private static void addTerkait(Schema schema) {

        Entity challenge = schema.addEntity("Terkait");
        challenge.setHasKeepSections(true);
        challenge.setTableName("Terkait");

        challenge.addStringProperty("type");
        challenge.addStringProperty("id1");
        challenge.addStringProperty("id2");
        challenge.addStringProperty("playedAs");
        challenge.addStringProperty("descriptionCharacter");
    }

    private static void addJadwalBola(Schema schema) {
        Entity challenge = schema.addEntity("JadwalBola");
        challenge.setHasKeepSections(true);
        challenge.setTableName("JadwalBola");

        challenge.addStringProperty("channel");
        challenge.addStringProperty("club1");
        challenge.addStringProperty("club2");
        challenge.addStringProperty("time");
        challenge.addStringProperty("days");
        challenge.addDateProperty("date");
    }

    private static void addNewsGroup(Schema schema) {
        Entity challenge = schema.addEntity("NewsGroup");
        challenge.setHasKeepSections(true);
        challenge.setTableName("NewsGroup");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("name");
        challenge.addStringProperty("title");
        challenge.addStringProperty("description");
        challenge.addStringProperty("image");
        challenge.addStringProperty("category");
        challenge.addStringProperty("date");
    }

    private static void addItemNews(Schema schema) {
        Entity challenge = schema.addEntity("ItemNews");
        challenge.setHasKeepSections(true);
        challenge.setTableName("ItemNews");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("name");
        challenge.addStringProperty("title");
        challenge.addStringProperty("description");
        challenge.addStringProperty("groupId");
    }

    private static void addCategory(Schema schema) {
        Entity challenge = schema.addEntity("Category");
        challenge.setHasKeepSections(true);
        challenge.setTableName("Category");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("name");
        challenge.addStringProperty("title");
        challenge.addStringProperty("desc");
        challenge.addStringProperty("image");
        challenge.addStringProperty("count");
        challenge.addStringProperty("parent");
        challenge.addStringProperty("type");
    }

    private static void addFoto(Schema schema) {

        Entity challenge = schema.addEntity("Foto");
        challenge.setHasKeepSections(true);
        challenge.setTableName("Foto");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("file");
        challenge.addStringProperty("title");
        challenge.addStringProperty("description");
        challenge.addStringProperty("url");
        challenge.addStringProperty("thumb630");
        challenge.addStringProperty("thumb315");
    }

    private static void addWatchList(Schema schema) {
        Entity challenge = schema.addEntity("WatchList");
        challenge.setHasKeepSections(true);
        challenge.setTableName("WatchList");

        challenge.addStringProperty("activityId").primaryKey();
        challenge.addStringProperty("memberId");
        challenge.addStringProperty("objectId");
        challenge.addStringProperty("activityType");
        challenge.addStringProperty("programPdcId");
        challenge.addStringProperty("programPdcName");
        challenge.addStringProperty("programPdcTitle");
        challenge.addStringProperty("programPdcCategories");
        challenge.addStringProperty("programPdcChannel");
        challenge.addStringProperty("programPdcDescription");
        challenge.addStringProperty("programPdcImage");
        challenge.addStringProperty("programPdcCount");
        challenge.addDateProperty("date");
        challenge.addDoubleProperty("total_score");
    }

    private static void addUlasan(Schema schema) {
        Entity challenge = schema.addEntity("Ulasan");
        challenge.setHasKeepSections(true);
        challenge.setTableName("Ulasan");

        challenge.addStringProperty("reviewId").primaryKey();
        challenge.addStringProperty("memberId");
        challenge.addStringProperty("objectId");
        challenge.addStringProperty("ratingId");
        challenge.addStringProperty("reviewTitle");
        challenge.addStringProperty("reviewDescription");
        challenge.addStringProperty("approved");
        challenge.addStringProperty("objectType");
        challenge.addDateProperty("date");
        challenge.addStringProperty("memberName");
        challenge.addStringProperty("memberAvatar");
        challenge.addStringProperty("programId");
        challenge.addStringProperty("programName");
        challenge.addStringProperty("programTitle");
        challenge.addStringProperty("programCategories");
        challenge.addStringProperty("programChannel");
        challenge.addStringProperty("programDescription");
        challenge.addStringProperty("programImage");
        challenge.addStringProperty("programPdc");
        challenge.addDoubleProperty("rating");
    }

    private static void addRecommendedShow(Schema schema) {
        Entity challenge = schema.addEntity("RecommendedShow");
        challenge.setHasKeepSections(true);
        challenge.setTableName("RecommendedShow");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("name");
        challenge.addStringProperty("title");
        challenge.addStringProperty("image");
        challenge.addStringProperty("time");
        challenge.addStringProperty("timeEnd");
        challenge.addStringProperty("channel");
        challenge.addStringProperty("categories");
        challenge.addStringProperty("pdc");
        challenge.addDateProperty("date");
        challenge.addDoubleProperty("total_score");
    }

    private static void addNotification(Schema schema) {

        Entity challenge = schema.addEntity("Notification");
        challenge.setHasKeepSections(true);
        challenge.setTableName("Notification");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("message");
        challenge.addStringProperty("status");
        challenge.addDateProperty("date");
    }

    private static void addAktifitas(Schema schema) {
        Entity challenge = schema.addEntity("Aktifitas");
        challenge.setHasKeepSections(true);
        challenge.setTableName("Aktifitas");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("name");
        challenge.addStringProperty("memberId");
        challenge.addStringProperty("memberName");
        challenge.addStringProperty("memberImage");
        challenge.addStringProperty("programId");
        challenge.addStringProperty("programName");
        challenge.addStringProperty("programTitle");
        challenge.addStringProperty("programImage");
        challenge.addStringProperty("objectType");
        challenge.addStringProperty("actInfo");
        challenge.addDateProperty("date");
    }

    private static void addDetailAcara(Schema schema) {

        Entity challenge = schema.addEntity("DetailAcara");
        challenge.setHasKeepSections(true);
        challenge.setTableName("DetailAcara");

        challenge.addStringProperty("program_pdc_id").primaryKey();
        challenge.addStringProperty("program_pdc_name");
        challenge.addStringProperty("program_pdc_title");
        challenge.addStringProperty("program_pdc_categories");
        challenge.addStringProperty("program_pdc_channel");
        challenge.addStringProperty("program_pdc_description");
        challenge.addStringProperty("program_pdc_image");
        challenge.addStringProperty("program_pdc_count");
        challenge.addStringProperty("is_movie");
        challenge.addStringProperty("movie_categories");
        challenge.addStringProperty("web_url");
        challenge.addStringProperty("total_attendance");
        challenge.addStringProperty("total_reviews");
        challenge.addStringProperty("judgement");
        challenge.addBooleanProperty("already_setting_alarm");
        challenge.addBooleanProperty("already_save_mytvguide");
        challenge.addBooleanProperty("already_attend");
        challenge.addDoubleProperty("total_score");
    }

    private static void addAccount(Schema schema) {
        Entity challenge = schema.addEntity("Account");
        challenge.setHasKeepSections(true);
        challenge.setTableName("Account");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("name");
        challenge.addStringProperty("email");
        challenge.addStringProperty("password");
        challenge.addStringProperty("birth_date");
        challenge.addStringProperty("image");
        challenge.addStringProperty("gender");
        challenge.addStringProperty("totalAktifitas");
        challenge.addStringProperty("totalFollowing");
        challenge.addStringProperty("totalFollower");
        challenge.addBooleanProperty("tvguide_news");
        challenge.addBooleanProperty("tvguide_offer");
        challenge.addBooleanProperty("alreadyFollwing");
    }

    private static void addSelebrity(Schema schema) {
        Entity challenge = schema.addEntity("Selebrity");
        challenge.setHasKeepSections(true);
        challenge.setTableName("Selebrity");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("name");
        challenge.addStringProperty("slug");
        challenge.addStringProperty("description");
        challenge.addStringProperty("inFocus");
        challenge.addDateProperty("birth_date");
        challenge.addIntProperty("countNews");
        challenge.addIntProperty("countTvshows");
        challenge.addIntProperty("countVideos");
        challenge.addIntProperty("countPhotos");
        challenge.addStringProperty("professionTitle");
        challenge.addStringProperty("image");
        challenge.addStringProperty("gender");
        challenge.addStringProperty("professionId");
        challenge.addStringProperty("zodiak");
    }

    private static void addBerita(Schema schema) {

        Entity challenge = schema.addEntity("Berita");
        challenge.setHasKeepSections(true);
        challenge.setTableName("Berita");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("name");
        challenge.addStringProperty("title");
        challenge.addStringProperty("description");
        challenge.addStringProperty("category");
        challenge.addStringProperty("date");
        challenge.addStringProperty("dateId");
        challenge.addStringProperty("categoryId");
        challenge.addStringProperty("categoryName");
        challenge.addStringProperty("categoryTitle");
        challenge.addStringProperty("categoryDescription");
        challenge.addStringProperty("categoryCount");
        challenge.addStringProperty("categoryParent");
        challenge.addStringProperty("image");
        challenge.addStringProperty("totalComment");
        challenge.addStringProperty("inGroup");
        challenge.addStringProperty("isGroup");
        challenge.addStringProperty("webUrl");
    }

    private static void addFilm(Schema schema) {
        Entity challenge = schema.addEntity("Film");
        challenge.setHasKeepSections(true);
        challenge.setTableName("Film");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("name");
        challenge.addStringProperty("title");
        challenge.addStringProperty("image");
        challenge.addStringProperty("content");
        challenge.addStringProperty("date");
        challenge.addStringProperty("time");
        challenge.addStringProperty("time_end");
        challenge.addStringProperty("channelId");
        challenge.addStringProperty("categories");
        challenge.addStringProperty("pdc");
        challenge.addStringProperty("pilihan");
        challenge.addStringProperty("isMovie");
        challenge.addStringProperty("userClicks");
        challenge.addStringProperty("channelTitle");
        challenge.addStringProperty("channelImage");
    }

    private static void addAcaraSekarang(Schema schema) {
        Entity challenge = schema.addEntity("AcaraSekarang");
        challenge.setHasKeepSections(true);
        challenge.setTableName("AcaraSekarang");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("name");
        challenge.addStringProperty("title");
        challenge.addStringProperty("image");
        challenge.addStringProperty("content");
        challenge.addStringProperty("date");
        challenge.addStringProperty("time");
        challenge.addStringProperty("time_end");
        challenge.addStringProperty("channelId");
        challenge.addStringProperty("categories");
        challenge.addStringProperty("pdc");
        challenge.addStringProperty("pilihan");
        challenge.addStringProperty("isMovie");
        challenge.addStringProperty("userClicks");
        challenge.addStringProperty("channelTitle");
        challenge.addStringProperty("channelImage");
        challenge.addStringProperty("channelType");
    }

    private static void addFeatureProgram(Schema schema) {
        Entity challenge = schema.addEntity("FeatureProgram");
        challenge.setHasKeepSections(true);
        challenge.setTableName("FeatureProgram");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("name");
        challenge.addStringProperty("title");
        challenge.addStringProperty("image");
        challenge.addStringProperty("content");
        challenge.addStringProperty("date");
        challenge.addStringProperty("time");
        challenge.addStringProperty("time_end");
        challenge.addStringProperty("channelId");
        challenge.addStringProperty("categories");
        challenge.addStringProperty("pdc");
        challenge.addStringProperty("pilihan");
        challenge.addStringProperty("isMovie");
        challenge.addStringProperty("userClicks");
        challenge.addStringProperty("channelTitle");
        challenge.addStringProperty("channelImage");
    }

    private static void addChannel(Schema schema) {
        Entity challenge = schema.addEntity("Channel");
        challenge.setHasKeepSections(true);
        challenge.setTableName("Channel");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("name");
        challenge.addStringProperty("title");
        challenge.addStringProperty("image");
        challenge.addStringProperty("urlStreaming");
        challenge.addStringProperty("channelType");
    }

    private static void addTag(Schema schema) {
        Entity challenge = schema.addEntity("Tag");
        challenge.setHasKeepSections(true);
        challenge.setTableName("Tag");

        challenge.addStringProperty("id").primaryKey();
        challenge.addStringProperty("object");
        challenge.addStringProperty("objectId");
        challenge.addStringProperty("tagName");
        challenge.addStringProperty("tagTitle");
        challenge.addStringProperty("tagDescription");
        challenge.addStringProperty("dataCount");
    }

}
