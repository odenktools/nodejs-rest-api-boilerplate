https://androidbelieve.com/navigation-drawer-with-swipe-tabs-using-design-support-library/


curl -H "Accept: application/json" -H "Content-Type: application/json" -X POST -d '{"username":"xyz","email":"xyz@berek.com"}' http://localhost/ci-restapi/api/uniresttest/tester

curl -H "Content-Type: application/json; charset=UTF-8" -X POST -d '{"username":"xyz","email":"xyz@berek.com"}' http://localhost/ci-restapi/api/uniresttest/tester

curl -H "Content-Type: application/x-www-form-urlencoded; charset=UTF-8" -X POST -d 'username=value1&email=value2' http://localhost/ci-restapi/api/uniresttest/tester



curl -H "Content-Type: application/json; charset=UTF-8" -X POST -d '{"api_key":"202207210904052014","action":"get_episode_by_channel", "date":"2016-01-06", "channel_id":21}' http://tvguide.co.id/tvguide_api/catch

curl -H "Content-Type: application/x-www-form-urlencoded; charset=UTF-8" -X POST -d 'api_key=202207210904052014&action=get_episode_by_channel&date=2016-01-06&channel_id=21' http://tvguide.co.id/tvguide_api/catch