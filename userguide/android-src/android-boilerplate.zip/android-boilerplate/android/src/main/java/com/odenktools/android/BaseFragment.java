package com.odenktools.android;

import android.support.v4.app.Fragment;
import com.odenktools.android.dao.DaoSession;

public class BaseFragment extends Fragment {

    protected static BaseActivity mBaseActivity;

    protected BaseActivity getBaseAct() {
        return ((BaseActivity) getActivity());
    }

    public DaoSession getDaoSession() {
        return ApplicationController.getInstance().getDaoSession();
        //return ((ApplicationController) mBaseActivity.getApplication()).getDaoSession();
    }

}
