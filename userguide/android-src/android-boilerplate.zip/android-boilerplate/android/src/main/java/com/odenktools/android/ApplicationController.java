package com.odenktools.android;

import android.app.Application;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.odenktools.android.dao.DaoMaster;
import com.odenktools.android.dao.DaoSession;

public class ApplicationController extends Application {

    private static ApplicationController sInstance;
    private DaoSession mDaoSession;

    private RequestQueue mRequestQueue;

    @Override
    public void onCreate() {
        super.onCreate();

        mRequestQueue = Volley.newRequestQueue(this);

        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(this, "tvguide-db", null);
        SQLiteDatabase db = helper.getWritableDatabase();
        DaoMaster daoMaster = new DaoMaster(db);
        mDaoSession = daoMaster.newSession();

        Log.v("ApplicationController", "CREATING ApplicationController");

        sInstance = this;
    }

    public synchronized static ApplicationController getInstance() {
        return sInstance;
    }

    public RequestQueue getRequestQueue() {
        return mRequestQueue;
    }

    public DaoSession getDaoSession() {
        return mDaoSession;
    }
}
