package com.odenktools.android;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

/**
 * Created by Ratan on 7/29/2015.
 */
public class SocialFragment extends BaseFragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //Toast.makeText(getActivity() , "SocialFragment", Toast.LENGTH_SHORT).show();

        return inflater.inflate(R.layout.social_layout,null);
    }


}
