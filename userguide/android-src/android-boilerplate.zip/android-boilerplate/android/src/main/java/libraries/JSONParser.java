package libraries;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Base64;
import android.util.Log;

public class JSONParser {

	static InputStream is = null;
	static JSONObject jObj = null;
	static String json = "";

	public static String UserName;
	public static String Password;
	private static final String USER_NAME = "moeloet";
	private static final String PASSWORD = "moeloet";
	
	// constructor
	public JSONParser() {

	}

	/**
	 * 
	 * @param is
	 * @return
	 */
	public String ConvertStreamToString(InputStream is) {
		/*
		 * To convert the InputStream to String we use the
		 * BufferedReader.readLine() method. We iterate until the BufferedReader
		 * return null which means there's no more data to read. Each line will
		 * appended to a StringBuilder and returned as String.
		 */
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();

		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return sb.toString();
	}

	/**
	 * 
	 * @param url
	 * @return
	 */
	public JSONObject JSONListFromUrl(String url) {

		// initialize
		InputStream is = null;
		String result = "";
		JSONObject jArray = null;

		try {

			CredentialsProvider credProvider = new BasicCredentialsProvider();
			credProvider.setCredentials(new AuthScope(AuthScope.ANY_HOST,
					AuthScope.ANY_PORT), new UsernamePasswordCredentials(
					UserName, Password));

			DefaultHttpClient httpclient = new DefaultHttpClient();

			httpclient.setCredentialsProvider(credProvider);

			HttpGet getRequest = new HttpGet(url);

			HttpResponse response = httpclient.execute(getRequest);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();

		} catch (Exception e) {
			Log.e("log_tag", "Error in http connection " + e.toString());
		}

		/**
		 * convert response to string
		 */
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();
			result = sb.toString();
		} catch (Exception e) {
			Log.e("log_tag", "Error converting result " + e.toString());
		}

		/**
		 * try parse the string to a JSON object
		 */
		try {
			jArray = new JSONObject(result);
		} catch (JSONException e) {
			Log.e("log_tag", "Error parsing data " + e.toString());
		}

		return jArray;
	}

	/**
	 * Example Usage : String jResult = jParser.JSONString("{"id":"1"}");
	 * 
	 * @param url
	 * @return String
	 */
	public String JSONString(String url) {

		InputStream is = null;
		String result = "";
		JSONObject jArray = null;

		try {

			CredentialsProvider credProvider = new BasicCredentialsProvider();
			credProvider.setCredentials(new AuthScope(AuthScope.ANY_HOST,
					AuthScope.ANY_PORT), new UsernamePasswordCredentials(
					UserName, Password));

			DefaultHttpClient httpclient = new DefaultHttpClient();

			httpclient.setCredentialsProvider(credProvider);

			HttpGet getRequest = new HttpGet(url);

			getRequest.setHeader("Content-Type", "application/json");

			getRequest.setHeader("Accept", "application/json");

			HttpResponse response = httpclient.execute(getRequest);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();

		} catch (Exception e) {
			Log.e("log_tag", "Error in http connection " + e.toString());
		}

		/**
		 * convert response to string
		 */
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();
			result = sb.toString();
		} catch (Exception e) {
			Log.e("log_tag", "Error converting result " + e.toString());
		}

		return result;
	}

	/**
	 * 
	 * @param url
	 * @param params
	 * @return
	 */
	public JSONObject GetJSONFromUrl(String url, List<NameValuePair> params) {

		// Making HTTP request
		try {

			CredentialsProvider credProvider = new BasicCredentialsProvider();
			credProvider.setCredentials(new AuthScope(AuthScope.ANY_HOST,
					AuthScope.ANY_PORT), new UsernamePasswordCredentials(
					UserName, Password));

			DefaultHttpClient httpClient = new DefaultHttpClient();

			// Set the credential
			httpClient.setCredentialsProvider(credProvider);

			HttpPost httpPost = new HttpPost(url);

			// httpPost.addHeader("X_ASCCPE_USERNAME", UserName);
			// httpPost.addHeader("X_ASCCPE_PASSWORD", Password);

			httpPost.setEntity(new UrlEncodedFormEntity(params));

			HttpResponse httpResponse = httpClient.execute(httpPost);

			httpResponse.setHeader("Content-Type", "application/json");

			HttpEntity httpEntity = httpResponse.getEntity();
			is = httpEntity.getContent();

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		try {

			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);

			StringBuilder sb = new StringBuilder();
			String line = null;

			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}

			is.close();
			json = sb.toString();
			Log.e("JSON", json);

		} catch (Exception e) {
			Log.e("Buffer Error", "Error converting result " + e.toString());
		}

		// try parse the string to a JSON object
		try {
			jObj = new JSONObject(json);

		} catch (JSONException e) {
			Log.e("JSON Parser", "Error parsing data " + e.toString());
		}

		// return JSON String
		return jObj;

	}

	public void basicAuthDemo(String url) {

		String credentials = USER_NAME + ":" + PASSWORD;

		String base64EncodedCredentials = Base64.encodeToString(
				credentials.getBytes(), Base64.NO_WRAP);

		DefaultHttpClient httpclient = new DefaultHttpClient();

		try {

			HttpGet httpget = new HttpGet(url);

			httpget.addHeader("Authorization", "Basic "
					+ base64EncodedCredentials);

			System.out.println("executing request" + httpget.getRequestLine());
			HttpResponse response = httpclient.execute(httpget);
			HttpEntity entity = response.getEntity();

			System.out.println("----------------------------------------");
			System.out.println(response.getStatusLine());
			if (entity != null) {
				System.out.println("Response content length: "
						+ entity.getContentLength());
				System.out.println(EntityUtils.toString(entity));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// When HttpClient instance is no longer needed,
			// shut down the connection manager to ensure
			// immediate deallocation of all system resources
			httpclient.getConnectionManager().shutdown();
		}
	}

	/**
	 * 
	 * @param url
	 * @param params
	 * @return
	 */
	public JSONObject JSONPost(String url, List<NameValuePair> params) {

		String credentials = USER_NAME + ":" + PASSWORD;

		String base64EncodedCredentials = Base64.encodeToString(
				credentials.getBytes(), Base64.NO_WRAP);

		// CredentialsProvider credProvider = new BasicCredentialsProvider();
		//
		// credProvider.setCredentials(new AuthScope(AuthScope.ANY_HOST,
		// AuthScope.ANY_PORT), new UsernamePasswordCredentials(
		// USER_NAME, PASSWORD));

		DefaultHttpClient httpClient = new DefaultHttpClient();

		// httpClient.setCredentialsProvider(credProvider);

		HttpPost httpPost = new HttpPost(url);

		httpPost.addHeader("Authorization", "Basic " + base64EncodedCredentials);

		// httpPost.setHeader("Content-Type", "application/json");

		httpPost.setHeader("Content-Type", "application/x-www-form-urlencoded");

		HttpResponse response = null;

		JSONObject json = null;

		try {

			httpPost.setEntity(new UrlEncodedFormEntity(params));

			response = httpClient.execute(httpPost);

			Log.i("POST status code:", response.getStatusLine().toString());

			StatusLine statusLine = response.getStatusLine();

			int statusCode = statusLine.getStatusCode();

			HttpEntity entityResp = response.getEntity();

			if (statusCode == 200) {

				if (entityResp != null) {

					InputStream instream = entityResp.getContent();
					String result = ConvertStreamToString(instream);

					Log.i("callback result : ", result);

					json = new JSONObject(result);
					instream.close();
				}
			} else if (statusCode == 401) {

				InputStream instream = entityResp.getContent();
				String result = ConvertStreamToString(instream);

				json = new JSONObject(result);
				instream.close();

			} else if (statusCode == 500) {

				InputStream instream = entityResp.getContent();
				String result = ConvertStreamToString(instream);

				json = new JSONObject(result);
				instream.close();

			} else if (statusCode == 400) {

				InputStream instream = entityResp.getContent();
				String result = ConvertStreamToString(instream);

				json = new JSONObject(result);
				instream.close();
			}

		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return json;
	}

	/**
	 * function get json from url by making HTTP POST or GET method
	 * 
	 * @param url
	 * @param method
	 * @param params
	 * @return
	 */
	public String makeHttpRequest(String url, String method,
			List<NameValuePair> params) {

		String credentials = USER_NAME + ":" + PASSWORD;

		String base64EncodedCredentials = Base64.encodeToString(
				credentials.getBytes(), Base64.NO_WRAP);

		
		// Making HTTP request
		try {

			// check for request method
			if (method == "POST") {
				// request method is POST
				// defaultHttpClient
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost(url);
				httpPost.setEntity(new UrlEncodedFormEntity(params));

				HttpResponse httpResponse = httpClient.execute(httpPost);
				HttpEntity httpEntity = httpResponse.getEntity();
				is = httpEntity.getContent();

			} else if (method == "GET") {
				// request method is GET
				DefaultHttpClient httpClient = new DefaultHttpClient();
				

				
				String paramString = URLEncodedUtils.format(params, "utf-8");
				//url += "?" + paramString;
				url += paramString;
				HttpGet httpGet = new HttpGet(url);

				httpGet.addHeader("Authorization", "Basic "
						+ base64EncodedCredentials);
				
				HttpResponse httpResponse = httpClient.execute(httpGet);
				HttpEntity httpEntity = httpResponse.getEntity();
				is = httpEntity.getContent();
			}

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();
			json = sb.toString();
		} catch (Exception e) {
			Log.e("Buffer Error", "Error converting result " + e.toString());
		}

		// return JSON String
		return json;

	}
}
