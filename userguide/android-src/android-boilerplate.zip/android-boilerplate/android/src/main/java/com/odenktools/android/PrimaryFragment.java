package com.odenktools.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import com.odenktools.android.dao.AcaraSekarang;
import com.odenktools.android.dao.AcaraSekarangDao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


import org.apache.http.NameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import libraries.JSONParser;

import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import android.os.Handler;


import libraries.koushikdutta.async.http.socketio.Acknowledge;
import libraries.koushikdutta.async.http.socketio.ConnectCallback;
import libraries.koushikdutta.async.http.socketio.DisconnectCallback;
import libraries.koushikdutta.async.http.socketio.EventCallback;
import libraries.koushikdutta.async.http.socketio.JSONCallback;
import libraries.koushikdutta.async.http.socketio.SocketIOClient;
import libraries.koushikdutta.async.http.socketio.StringCallback;
import org.json.JSONObject;


public class PrimaryFragment extends BaseFragment {


    /**
     * called once the fragment is associated with its activity.
     *
     * @param context context
     */
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mBaseActivity = (BaseActivity) getContext();
        Log.v("PrimaryFragment", "onAttach");
    }

//    @SuppressWarnings("deprecation")
//    @Override
//    public void onAttach(Activity activity) {
//        super.onAttach(activity);
//        mBaseActivity = (BaseActivity) activity;
//        Log.v("PrimaryFragment", "onAttach");
//    }

    /**
     * creates and returns the view hierarchy associated with the fragment.
     *
     * @param inflater           inflater
     * @param container          container
     * @param savedInstanceState savedInstanceState
     * @return
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //Toast.makeText(getActivity() , "PrimaryFragment", Toast.LENGTH_SHORT).show();

        Log.v("PrimaryFragment", "onCreateView");
        return inflater.inflate(R.layout.primary_layout, null);
    }

    /**
     * tells the fragment that its activity has completed its own Activity.onCreate().
     *
     * @param savedInstanceState savedInstanceState
     */
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Log.v("PrimaryFragment", "onActivityCreated");
    }

}
