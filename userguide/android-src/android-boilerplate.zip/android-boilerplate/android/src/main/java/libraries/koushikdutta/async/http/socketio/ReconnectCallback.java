package libraries.koushikdutta.async.http.socketio;

public interface ReconnectCallback {
    public void onReconnect();
}