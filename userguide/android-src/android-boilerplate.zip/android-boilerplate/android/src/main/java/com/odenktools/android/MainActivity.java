package com.odenktools.android;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;

import android.widget.ImageView;
import android.widget.Toast;
import com.android.volley.*;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import libraries.JSONParser;
import libraries.koushikdutta.async.http.socketio.*;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.entity.ByteArrayEntity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import uk.co.senab.photoview.PhotoViewAttacher;
import com.odenktools.android.dao.AcaraSekarang;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends BaseActivity {

    DrawerLayout mDrawerLayout;
    NavigationView mNavigationView;
    FragmentManager mFragmentManager;
    FragmentTransaction mFragmentTransaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /**
         *Setup the DrawerLayout and NavigationView
         */
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        mNavigationView = (NavigationView) findViewById(R.id.shitstuff);

        /**
         * Lets inflate the very first fragment
         * Here , we are inflating the TabFragment as the first Fragment
         */

        mFragmentManager = getSupportFragmentManager();
        mFragmentTransaction = mFragmentManager.beginTransaction();
        mFragmentTransaction.replace(R.id.containerView, new TabFragment()).commit();

        /**
         * Setup click events on the Navigation View Items.
         */
        mNavigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                mDrawerLayout.closeDrawers();


                if (menuItem.getItemId() == R.id.nav_item_sent) {
                    FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.containerView, new SentFragment()).commit();

                }

                if (menuItem.getItemId() == R.id.nav_item_inbox) {
                    FragmentTransaction xfragmentTransaction = mFragmentManager.beginTransaction();
                    xfragmentTransaction.replace(R.id.containerView, new TabFragment()).commit();
                }

                return false;
            }

        });

        /**
         * Setup Drawer Toggle of the Toolbar
         */
        android.support.v7.widget.Toolbar toolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar);
        ActionBarDrawerToggle mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.app_name,
                R.string.app_name);

        mDrawerLayout.setDrawerListener(mDrawerToggle);

        mDrawerToggle.syncState();

        getEmit();
    }

    private byte[] encodeParameters(Map<String, String> params, String paramsEncoding) {
        StringBuilder encodedParams = new StringBuilder();
        try {
            for (Map.Entry<String, String> entry : params.entrySet()) {
                encodedParams.append(URLEncoder.encode(entry.getKey(), paramsEncoding));
                encodedParams.append('=');
                encodedParams.append(URLEncoder.encode(entry.getValue(), paramsEncoding));
                encodedParams.append('&');
            }
            return encodedParams.toString().getBytes(paramsEncoding);
        } catch (UnsupportedEncodingException uee) {
            throw new RuntimeException("Encoding not supported: " + paramsEncoding, uee);
        }
    }

    Map<String, String> createBasicAuthHeader(String username, String password) {
        Map<String, String> headerMap = new HashMap<String, String>();

        String credentials = username + ":" + password;
        String encodedCredentials = Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
        headerMap.put("Authorization", "Basic " + encodedCredentials);

        return headerMap;
    }




    JSONParser jsonParser = new JSONParser();
    JSONObject object = null;
    JSONArray users = null;
    JSONArray userParse = null;


    // ALL JSON
    private static final String TAG_ID = "ID";
    private static final String TAG_BRANCH_ID = "branch_id";
    private static final String TAG_ROLE_ID = "role_id";
    private static final String TAG_USERNAME = "username";
    private static final String TAG_PASSWD = "passwd";
    private static final String TAG_GENDER = "gender";
    private static final String TAG_USERMAIL = "usermail";
    private static final String TAG_ACTIVE = "active";
    private static final String TAG_SUPERUSER = "superuser";
    private static final String TAG_CREATED_AT = "created_at";
    private static final String TAG_LAST_LOGIN = "last_login";
    private static final String TAG_LOGIN_COUNT = "login_count";

    String IPServer = "192.168.2.86";

    final String Uri = "http://" + IPServer + ":9999";
    public void getEmit() {

        SocketIOClient.connect(Uri,
                new ConnectCallback() {

                    @Override
                    public void onConnectCompleted(Exception ex,
                                                   SocketIOClient client) {

                        if (ex != null) {
                            ex.printStackTrace();
                            return;
                        }

                        client.setStringCallback(new StringCallback() {
                            @Override
                            public void onString(String string,
                                                 Acknowledge acknowledge) {
                                Log.i("onString", string);
                            }
                        });

                        client.setJSONCallback(new JSONCallback() {
                            @Override
                            public void onJSON(JSONObject json,
                                               Acknowledge acknowledge) {

                                Log.i("setJSONCallback", json.toString());
                            }
                        });

                        client.setDisconnectCallback(new DisconnectCallback() {

                            @Override
                            public void onDisconnect(Exception e) {

                                Log.i("onDisconnect",
                                        "SERVER TELAH DISKONEK");

                            }
                        });

                        client.addListener("server-Mahasiswa-doInsertLoad",
                                new EventCallback() {

                                    @Override
                                    public void onEvent(String event,
                                                        JSONArray argument,
                                                        Acknowledge acknowledge) {

//                                        Toast.makeText(
//                                                MainActivity.this,
//                                                "Another client was INSERTED record",
//                                                Toast.LENGTH_SHORT)
//                                                .show();

                                        for (int k = 0; k < argument.length(); k++) {

                                            try {

                                                JSONObject jb = (JSONObject) argument
                                                        .get(k);

                                                Log.d("SSSSSSSSSSSSSS", jb.toString());

                                                String recs = jb.getString("nama_mhs");

                                                Toast.makeText(MainActivity.this,
                                                        recs + " was INSERTED!",
                                                        Toast.LENGTH_SHORT)
                                                        .show();

                                            } catch (JSONException e) {

                                                e.printStackTrace();
                                            }
                                        }

                                    }
                                });


                        client.addListener("server-Mahasiswa-get-record",
                                new EventCallback() {

                                    @Override
                                    public void onEvent(String event,
                                                        JSONArray argument,
                                                        Acknowledge acknowledge) {

//                                        Toast.makeText(
//                                                MainActivity.this,
//                                                "another client was fetch records",
//                                                Toast.LENGTH_SHORT)
//                                                .show();

                                        for (int k = 0; k < argument.length(); k++) {

                                            try {

                                                JSONObject jb = (JSONObject) argument
                                                        .get(k);

                                                JSONArray recs = (JSONArray) jb
                                                        .getJSONArray("records");

                                                for (int j = 0; j < recs.length(); j++) {

                                                    JSONObject jb2 = (JSONObject) recs
                                                            .get(j);

                                                    String nama_mhs = jb2.getString("nama_mhs");

                                                    //Log.i("name is", username);

                                                    Toast.makeText(MainActivity.this,
                                                            "Hellowww " + nama_mhs + "!",
                                                            Toast.LENGTH_SHORT)
                                                            .show();
                                                }

                                            } catch (JSONException e) {

                                                e.printStackTrace();
                                            }
                                        }
                                    }
                                });

                    }

                }, new Handler());

    }

}