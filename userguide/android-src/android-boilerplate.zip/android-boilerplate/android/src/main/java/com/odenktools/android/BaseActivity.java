package com.odenktools.android;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import com.odenktools.android.dao.DaoSession;

public class BaseActivity  extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public DaoSession getDaoSession() {
        return ApplicationController.getInstance().getDaoSession();
    }

}
